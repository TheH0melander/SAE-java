package main.phase2;

import ardoise.Ardoise;
import ardoise.Forme;
import ardoise.PointPlan;
import ardoise.mesformes.Chapeau;
import ardoise.mesformes.FormeComplexe;
import ardoise.mesformes.Quadrilatere;
import ardoise.mesformes.Triangle;

/**
 * Classe de Teste de la phase 2 
 * <br> On teste la création d'une frome composée (FormeComplexe)
 * <br> La forme complexe dite maison
 * 
 * @author Yanis KRIM
 *
 */
public class TestDessinAmelioration {
	public static void main(String[] args) throws Exception {
		Forme oiseau1 = new Chapeau(
				"Oiseau 1", 
				new PointPlan(118,13), 
				new PointPlan(123,20), 
				new PointPlan(128,13)
		);
		
		Forme oiseau2 = new Chapeau(
				"Oiseau 2", 
				new PointPlan(133,30), 
				new PointPlan(136,32), 
				new PointPlan(138,30)
		);
		
		Forme oiseau3 = new Chapeau(
				"Oiseau 3", 
				new PointPlan(142,14), 
				new PointPlan(144,17), 
				new PointPlan(146,14)
		);
		
		Forme tour = new Quadrilatere(
				"Tour", 
				new PointPlan(9,100), 
				new PointPlan(20,198)
		);
		
		Forme corpsMaisson = new Quadrilatere(
				"Corps maison", 
				new PointPlan(80,140), 
				new PointPlan(180,198)
		);
		Forme toitMaison = new Chapeau(
				"Toit maison", 
				new PointPlan(80,140), 
				new PointPlan(130,100), 
				new PointPlan(180,140)
		);
		Forme porteMaisson = new Quadrilatere(
				"Porte maison", 
				new PointPlan(120,170), 
				new PointPlan(140,198)
		);
		
		Forme formes[] = { corpsMaisson, toitMaison, porteMaisson };
		Forme maison = new FormeComplexe("Maison", formes);
		
		Forme branche1 = new Chapeau(
				"branche 1", 
				new PointPlan(170,52), 
				new PointPlan(173,45), 
				new PointPlan(177,52)
		);
		
		Forme branche2 = new Chapeau(
				"branche 2", 
				new PointPlan(177,52), 
				new PointPlan(184,57), 
				new PointPlan(177,60)
		);
		
		Forme branche3 = new Chapeau(
				"branche 3", 
				new PointPlan(177,60), 
				new PointPlan(174,66), 
				new PointPlan(170,60)
		);
		
		Forme branche4 = new Chapeau(
				"branche 4", 
				new PointPlan(170,60), 
				new PointPlan(164,57), 
				new PointPlan(170,52)
		);
		
		Forme montagne1 = new Triangle(
				"Montagne 1", 
				new PointPlan(3,14), 
				new PointPlan(43,3), 
				new PointPlan(112,14)
		);
		
		Forme montagne2 = new Triangle(
				"Montagne 2", 
				new PointPlan(152,7), 
				new PointPlan(166,3), 
				new PointPlan(172,7)
		);
		
		Ardoise ardoise = new Ardoise();
		
		ardoise.ajouterForme(oiseau1);
		ardoise.ajouterForme(oiseau2);
		ardoise.ajouterForme(oiseau3);
		
		ardoise.ajouterForme(tour);
		
		
//		ardoise.ajouterForme(corpsMaisson);
//		ardoise.ajouterForme(toitMaison);
//		ardoise.ajouterForme(porteMaisson);
		
		if (maison != null) {
			ardoise.ajouterForme(maison);
		}
		
		ardoise.ajouterForme(branche1);
		ardoise.ajouterForme(branche2);
		ardoise.ajouterForme(branche3);
		ardoise.ajouterForme(branche4);
		
		ardoise.ajouterForme(montagne1);
		ardoise.ajouterForme(montagne2);
		
		ardoise.dessinerGraphique();
	}
}
