package main.phase1.question3.tests1;

import ardoise.Ardoise;
import ardoise.Forme;
import ardoise.PointPlan;
import ardoise.mesformes.Chapeau;
import ardoise.mesformes.Quadrilatere;
import ardoise.mesformes.Triangle;

public class TestCheapeau {
	public static void main(String[] args) throws Exception {
		Forme triangle = new Triangle(
				"triangle-1", 
				new PointPlan(10, 10), 
				new PointPlan(100, 100), 
				new PointPlan(10, 100)
		);
		
		Forme quadri = new Quadrilatere(
				"quadritere-1", 
				new PointPlan(100, 100), 
				new PointPlan(180, 200)
		);
		
		Forme chapeau = new Chapeau("chapeau-1", 
				new PointPlan(118,13),
				new PointPlan(123,20), 
				new PointPlan(128,13)
		);
		
		Ardoise ardoise = new Ardoise();
		
		ardoise.ajouterForme(triangle);
		ardoise.ajouterForme(quadri);
		ardoise.ajouterForme(chapeau);
		
		ardoise.dessinerGraphique();
	}
}
