package main.phase1.question3.tests1;

import ardoise.Ardoise;
import ardoise.Forme;
import ardoise.PointPlan;
import ardoise.mesformes.Quadrilatere;
import ardoise.mesformes.Triangle;

public class TestQuadritere {
	public static void main(String[] args)  throws Exception {
		Forme triangle = new Triangle(
				"triangle-1", 
				new PointPlan(10, 10), 
				new PointPlan(100, 100), 
				new PointPlan(10, 100)
		);
		
		Forme quadri = new Quadrilatere(
				"quadritere-1", 
				new PointPlan(100, 100), 
				new PointPlan(180, 200)
		);
		
		Ardoise ardoise = new Ardoise();
		
		ardoise.ajouterForme(triangle);
		ardoise.ajouterForme(quadri);
		
		ardoise.dessinerGraphique();
	}
}
