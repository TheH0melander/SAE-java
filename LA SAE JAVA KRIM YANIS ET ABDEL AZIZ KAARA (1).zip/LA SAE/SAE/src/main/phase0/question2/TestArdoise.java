package main.phase0.question2;

import ardoise.Ardoise;

public class TestArdoise {
	public static void main(String[] args) {
		Ardoise ardoise = new Ardoise();
		ardoise.test();
	}
}
