package main.phase3;

import ardoise.Ardoise;
import ardoise.Forme;
import ardoise.PointPlan;
import ardoise.mesformes.Chapeau;

/**
 * Classe de Teste de la phase 3 
 * <br> On teste les situations d'erreur
 * <br> Situation 1 : deux points identique
 * 
 * @author Yanis KRIM
 *
 */
public class TestErreur01 {
	public static void main(String[] args) throws Exception {
		Forme oiseau1 = new Chapeau(
				"Oiseau 1", 
				new PointPlan(118,13), 
				new PointPlan(118,13), 
				new PointPlan(128,13)
		);
		
		Ardoise ardoise = new Ardoise();
		ardoise.ajouterForme(oiseau1);
		
		ardoise.dessinerGraphique();
	}
}
