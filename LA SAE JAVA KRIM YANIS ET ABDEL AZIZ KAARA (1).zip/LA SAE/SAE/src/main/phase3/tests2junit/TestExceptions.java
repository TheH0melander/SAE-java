package main.phase3.tests2junit;

import org.junit.Test;

import ardoise.Ardoise;
import ardoise.Forme;
import ardoise.PointPlan;
import ardoise.exceptions.CoordonneesPointErroneesExcption;
import ardoise.exceptions.DeuxPointsHorizontalOuVertical;
import ardoise.exceptions.DeuxPointsIndentiqueException;
import ardoise.exceptions.NombreFormesComposantsInsuffisantException;
import ardoise.exceptions.PointsSurLaMemeLigneException;
import ardoise.mesformes.Chapeau;
import ardoise.mesformes.FormeComplexe;
import ardoise.mesformes.Quadrilatere;

public class TestExceptions {

	@Test(expected = DeuxPointsIndentiqueException.class)
	public void testDeuxPointsIndentiqueException() throws Exception {
		Forme oiseau1 = new Chapeau(
				"Oiseau 1", 
				new PointPlan(118,13), 
				new PointPlan(118,13), 
				new PointPlan(128,13)
		);
		
		Ardoise ardoise = new Ardoise();
		ardoise.ajouterForme(oiseau1);
		
		ardoise.dessinerGraphique();
	}
	
	
	@Test(expected = PointsSurLaMemeLigneException.class)
	public void testDeuxPointsSurLaMemeLigneException() throws Exception {
		Forme oiseau1 = new Chapeau(
				"Oiseau 1", 
				new PointPlan(118,13), 
				new PointPlan(123,20), 
				new PointPlan(128,27)
		);
		
		Ardoise ardoise = new Ardoise();
		ardoise.ajouterForme(oiseau1);
		
		ardoise.dessinerGraphique();
	}
	
	@Test(expected = DeuxPointsHorizontalOuVertical.class)
	public void testDeuxDeuxPointsHorizontalOuVertical() throws Exception {
		Forme corpsMaisson = new Quadrilatere(
				"Corps maison", 
				new PointPlan(80,140), 
				new PointPlan(80,198)
		);
		
		Ardoise ardoise = new Ardoise();
		ardoise.ajouterForme(corpsMaisson);
		
		ardoise.dessinerGraphique();
	}
	
	@Test(expected = NombreFormesComposantsInsuffisantException.class)
	public void testNombreFormesComposantsInsuffisantException() throws Exception {
		Forme corpsMaisson = new Quadrilatere(
				"Corps maison", 
				new PointPlan(80,140), 
				new PointPlan(180,198)
		);
		
		Forme maison = null;
		Forme formes[] = { corpsMaisson };
		maison = new FormeComplexe("Maison", formes);
		
		Ardoise ardoise = new Ardoise();
		ardoise.ajouterForme(maison);
		
		ardoise.dessinerGraphique();
	}

	
	@Test(expected = CoordonneesPointErroneesExcption.class)
	public void testCoordonneesPointErroneesExcption() throws Exception {
		new Quadrilatere(
				"Corps maison", 
				new PointPlan(-80,140), 
				new PointPlan(180,198)
		);
	}
}
