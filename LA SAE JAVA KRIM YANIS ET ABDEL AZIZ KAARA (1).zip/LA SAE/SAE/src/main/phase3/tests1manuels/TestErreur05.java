package main.phase3.tests1manuels;

import ardoise.Ardoise;
import ardoise.Forme;
import ardoise.PointPlan;
import ardoise.mesformes.Chapeau;
import ardoise.mesformes.FormeComplexe;
import ardoise.mesformes.Quadrilatere;

/**
 * Classe de Teste de la phase 3 
 * <br> <br> On teste les situations d'erreur
 * <br> Situation 5 : vérification des coordonées des pionts
 * 
 * @author Yanis KRIM
 *
 */
public class TestErreur05 {
	public static void main(String[] args) throws Exception {
		Forme corpsMaisson = new Quadrilatere(
				"Corps maison", 
				new PointPlan(-80,140), 
				new PointPlan(180,198)
		);
		Forme toitMaison = new Chapeau(
				"Toit maison", 
				new PointPlan(80,140), 
				new PointPlan(130,100), 
				new PointPlan(180,140)
		);
		Forme porteMaisson = new Quadrilatere(
				"Porte maison", 
				new PointPlan(120,170), 
				new PointPlan(140,198)
		);
		
		Forme maison = null;
		try {
			Forme formes[] = { corpsMaisson, toitMaison, porteMaisson };
			maison = new FormeComplexe("Maison", formes);
		}
		catch (Exception e) {
			e.printStackTrace();
			return;
		}
		
		Ardoise ardoise = new Ardoise();
		ardoise.ajouterForme(maison);
		
		ardoise.dessinerGraphique();
	}
}
