package main.phase3;

import ardoise.Ardoise;
import ardoise.Forme;
import ardoise.PointPlan;
import ardoise.mesformes.Quadrilatere;

/**
 * Classe de Teste de la phase 3 
 * <br> <br> On teste les situations d'erreur
 * <br> Situation 3 : deux points sur une même ligne horizontale ou verticale
 * 
 * @author Yanis KRIM
 *
 */
public class TestErreur03 {
	public static void main(String[] args) throws Exception {
		Forme corpsMaisson = new Quadrilatere(
				"Corps maison", 
				new PointPlan(80,140), 
				new PointPlan(80,198)
		);
		
		Ardoise ardoise = new Ardoise();
		ardoise.ajouterForme(corpsMaisson);
		
		ardoise.dessinerGraphique();
	}
}
