package ardoise.mesformes;

import java.util.ArrayList;

import ardoise.Forme;
import ardoise.PointPlan;
import ardoise.Segment;
import ardoise.exceptions.CoordonneesPointErroneesExcption;
import ardoise.exceptions.DeuxPointsIndentiqueException;
import ardoise.exceptions.PointsSurLaMemeLigneException;
import ardoise.utils.Utils;

/**
 * Cette classe permet de représenter un Chapeau
 * 
 * 
 * @author Yanis KRIM
 *
 */
public class Chapeau extends Forme {
	private PointPlan point1;
	private PointPlan point2;
	private PointPlan point3;
	
	public Chapeau(String nomForme, PointPlan point1, PointPlan point2, PointPlan point3)  throws PointsSurLaMemeLigneException, DeuxPointsIndentiqueException, CoordonneesPointErroneesExcption {
		super(nomForme);
				
		if (!Utils.coordonneCorrectes(point1)
				|| !Utils.coordonneCorrectes(point2)
				|| !Utils.coordonneCorrectes(point3)
		) {
			throw new CoordonneesPointErroneesExcption("Triangle ("+nomForme+")");
		}
		
		if ( Utils.deuxPointsIdentiques(point1, point2)
				|| Utils.deuxPointsIdentiques(point1, point3)
				|| Utils.deuxPointsIdentiques(point2, point3)
				) {
			throw new DeuxPointsIndentiqueException("Triangle ("+nomForme+")");
		}
		
		if ( Utils.surLaMemeLigne(point1, point2, point3) ) {
			throw new PointsSurLaMemeLigneException("Chapeau ("+nomForme+")", 3);
		}
		
		this.point1 = new PointPlan(point1.getAbscisse(), point1.getOrdonnee());
		this.point2 = new PointPlan(point2.getAbscisse(), point2.getOrdonnee());
		this.point3 = new PointPlan(point3.getAbscisse(), point3.getOrdonnee());
	}
	
	@Override
	public void deplacer(int dx, int dy) {
		this.point1.deplacer(dx, dy);
		this.point2.deplacer(dx, dy);
		this.point3.deplacer(dx, dy);
	}

	@Override
	public ArrayList<Segment> dessiner() {
		ArrayList<Segment> segments = new ArrayList<>();
		
		segments.add( new Segment(point1, point2) );
		segments.add( new Segment(point2, point3) );
		
		return segments;
	}

	@Override
	public String typeForme() {
		return "C";
	}

}
