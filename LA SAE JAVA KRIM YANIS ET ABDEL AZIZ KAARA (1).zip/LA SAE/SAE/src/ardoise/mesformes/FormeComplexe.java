package ardoise.mesformes;

import java.util.ArrayList;

import ardoise.Forme;
import ardoise.Segment;
import ardoise.exceptions.NombreFormesComposantsInsuffisantException;

/**
 * Cette classe permet de représenter une forme complexe 
 * (composé d'au moins deux formes)
 * 
 * @author Yanis KRIM
 *
 */
public class FormeComplexe extends Forme {
	private ArrayList<Forme> formesComposants;
	
	public FormeComplexe(String nomForme, Forme formes[]) throws NombreFormesComposantsInsuffisantException {
		super(nomForme);
		
		//Le nombre de formes doit être >= 2, 
		//sinon, on génère une exception NombreFormesComposantsInsuffisantException
		if (formes == null || formes.length < 2) {
			throw new NombreFormesComposantsInsuffisantException(nomForme);
		}
				
		formesComposants = new ArrayList<>();
		for (Forme forme : formes) {
			formesComposants.add(forme);
		}
	}
	
	@Override
	public void deplacer(int dx, int dy) {
		for (Forme forme : formesComposants) {
			forme.deplacer(dx, dy);
		}
	}

	@Override
	public ArrayList<Segment> dessiner() {
		ArrayList<Segment> segments = new ArrayList<>();
		
		for (Forme forme : formesComposants) {
			segments.addAll( forme.dessiner() );
		}
		
		return segments;
	}

	@Override
	public String typeForme() {
		return "GF";
	}

}
