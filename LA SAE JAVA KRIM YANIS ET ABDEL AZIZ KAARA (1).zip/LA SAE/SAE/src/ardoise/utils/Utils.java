package ardoise.utils;

import ardoise.PointPlan;

/**
 * Cette classe utilitaire, sans états, contient quelques méthodes statiques
 * pour indiquer quelques situations en les points...
 * 
 * @author Yanis KRIM
 *
 */
public final class Utils {
	private Utils() {
	}
	
	public static boolean surLaMemeLigne(PointPlan point1, PointPlan point2, PointPlan point3) {
		boolean surLaMemeLigne = (point1.getAbscisse() == point2.getAbscisse() && point1.getAbscisse() == point3.getAbscisse());
		if (!surLaMemeLigne) {
			double tang1 = (double)(point1.getOrdonnee()-point2.getOrdonnee()) / (double)(point1.getAbscisse()-point2.getAbscisse());
			double tang2 = (double)(point1.getOrdonnee()-point3.getOrdonnee()) / (double)(point1.getAbscisse()-point3.getAbscisse());
			if (Math.abs(tang1) == Math.abs(tang2)) {
				surLaMemeLigne = true;
			}
		}
		
		return surLaMemeLigne;
	}
	
	public static boolean surLaMemeLigneHorizontale(PointPlan point1, PointPlan point2) {
		return point1.getOrdonnee() == point2.getOrdonnee();
	}
	
	public static boolean surLaMemeLigneVerticale(PointPlan point1, PointPlan point2) {
		return point1.getAbscisse() == point2.getAbscisse();
	}
	
	public static boolean deuxPointsIdentiques(PointPlan point1, PointPlan point2) { 
		return point1.getOrdonnee() == point2.getOrdonnee() && point1.getAbscisse() == point2.getAbscisse();
	}
	
	public static boolean coordonneCorrectes(PointPlan point) {
		return
			(point.getAbscisse() >= 0 && point.getAbscisse() <= 200)
			&&
			(point.getOrdonnee() >= 0 && point.getOrdonnee() <= 200);
	}
}
