package ardoise.exceptions;

/**
 * Cette class d'exception réprésente l'erreur liée à la création d'une forme complexe
 * en utilisant une seule forme.
 * 
 * @author Yanis KRIM
 *
 */
public class NombreFormesComposantsInsuffisantException extends Exception {
	private static final long serialVersionUID = 1L;

	/**
	 * Constructeur de la classe NombreFormesComposantsInsuffisantException
	 */
	public NombreFormesComposantsInsuffisantException(String forme) {
		super("Erreur de création de forme Complexe ("+forme+") : Pour construire une forme complexe, il faut fournir au moins deux formes");
	}
}
