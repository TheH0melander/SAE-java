package ardoise.exceptions;

/**
 * Cette class représente une excption liée aux coordonnées 
 * endehor des bordure de la l'ardoise.
 * 
 * Si l'abscisse ou l'ordonné sont inférieur à Zéro ou Supérieur à 200 (taille de l'ardoise),
 * un exception sera déclenchée ...
 * 
 * @author Yanis KRIM
 *
 */
public class CoordonneesPointErroneesExcption extends Exception {
	private static final long serialVersionUID = 1L;

	/**
	 * Constructeur de la classe CoordonneesPointErroneesExcption
	 */
	public CoordonneesPointErroneesExcption(String forme) {
		super("Erreur de création de "+forme+" : Coordonnées de point endehors de la zone d'affichage (soit <0 ou > 200)");
	}
}
