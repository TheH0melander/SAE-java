package ardoise.exceptions;

/**
 * Cette class représente une excption liée au faite que deux points sont sur.  
 * la même ligne horizontale ou verticale
 * 
 * @author Yanis KRIM
 *
 */
public class DeuxPointsHorizontalOuVertical extends Exception {
	private static final long serialVersionUID = 1L;

	/**
	 * Constructeur de la classe PointsSurLaMemeLigneException
	 */
	public DeuxPointsHorizontalOuVertical(String forme) {
		super("Erreur de création de "+forme+" : Pour construire un "+forme+", il faut fournir deux points qui ne forment pas une ligne horizontale ou verticale");
	}
}
