package ardoise.exceptions;

/**
 * Cette class représente une excption liée au faite de fournir deux points  
 * ou plus qui ont les mêmes valeurs pour l'abscisse ou l'ordonnée : autrement dit
 * il s'agit du même point. 
 * 
 * @author Yanis KRIM
 *
 */
public class DeuxPointsIndentiqueException extends Exception {
	private static final long serialVersionUID = 1L;

	/**
	 * Constructeur de la classe PointsSurLaMemeLigneException
	 */
	public DeuxPointsIndentiqueException(String forme) {
		super("Erreur de création de "+forme+" : Pour construire un "+forme+", il faut fournir deux points qui ne forment pas une ligne horizontale ou verticale");
	}
}
