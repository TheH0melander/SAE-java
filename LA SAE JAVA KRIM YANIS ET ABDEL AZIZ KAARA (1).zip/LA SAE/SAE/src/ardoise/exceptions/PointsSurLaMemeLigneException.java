package ardoise.exceptions;

/**
 * Cette class représente l'erreur que trois points sont sur la même ligne.
 * 
 * @author Yanis KRIM
 *
 */
public class PointsSurLaMemeLigneException extends Exception {
	private static final long serialVersionUID = 1L;

	/**
	 * Constructeur de la classe PointsSurLaMemeLigneException
	 */
	public PointsSurLaMemeLigneException(String forme, int nbPionts) {
		super("Erreur de création de "+forme+" : Pour construire un "+forme+", il faut fournir "+nbPionts+" points qui ne sont pas sur la même ligne");
	}
}
